﻿# Alterston Light: установка и обновление на плате ESP32 в один заход - найти плату, понять, что на ней, копия или перенос настроек, прошивка.
# Запускается из 1_USTANOVIT.bat. Файлы прошивки и esptool лежат рядом, в папке files.
param([string]$Port, [ValidateSet('', '1', '2', '3', '4')][string]$Copy = '', [switch]$Auto, [string]$Store)   # для проверки без вопросов: -Auto -Port COM9 -Copy 1 -Store папка
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
# Окно консоли - на шрифт Consolas: старый «точечный» шрифт не показывает русские буквы в UTF-8 (вместо них «▼▼▼»)
try {
  Add-Type -Namespace AL -Name ConFont -MemberDefinition @'
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] public struct CFI { public uint cbSize; public uint nFont; public short X; public short Y; public int FontFamily; public int FontWeight; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string FaceName; }
[DllImport("kernel32.dll", SetLastError = true)] public static extern IntPtr GetStdHandle(int h);
[DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] public static extern bool SetCurrentConsoleFontEx(IntPtr h, bool max, ref CFI f);
'@ -ErrorAction Stop
  $cf = New-Object AL.ConFont+CFI; $cf.cbSize = [Runtime.InteropServices.Marshal]::SizeOf($cf); $cf.Y = 18; $cf.FontFamily = 54; $cf.FontWeight = 400; $cf.FaceName = 'Consolas'
  [void][AL.ConFont]::SetCurrentConsoleFontEx([AL.ConFont]::GetStdHandle(-11), $false, [ref]$cf)
  Start-Sleep -Milliseconds 200; Clear-Host   # после смены шрифта окно меняет размер; с чистого экрана текст не «съезжает», когда окно растягивают
} catch {}
$V = '0.7.5'
$files = $PSScriptRoot; $top = Split-Path $files -Parent
# копии плат и настройки храним в «Документах», а не рядом с установщиком: папку старой версии удаляют - копия пропала бы вместе с ней
$store = if ($Store) { $Store } else { Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Alterston Light' }; $mac = 'board'
$esptool = Join-Path $files 'esptool.exe'; $bin = "alterston_light_${V}_full.bin"
try { $Host.UI.RawUI.WindowTitle = "Alterston Light $V - установка" } catch {}

function Say([string]$t, [string]$c = 'Gray') { Write-Host $t -ForegroundColor $c }
function Ask([string]$t) { if ($Auto) { return '' } ; return Read-Host $t }
function Step([int]$n, [string]$t) { Write-Host ''; Write-Host "=== Шаг $n из 3. $t ===" -ForegroundColor Cyan }
function Done([int]$code) { Remove-Item (Join-Path $files '_full_xen.bin') -ErrorAction SilentlyContinue; if (-not $Auto) { Read-Host 'Нажми Enter, чтобы закрыть окно' | Out-Null }; exit $code }
function Fail([string]$t) { Say ''; Say $t 'Red'; Done 1 }
function UsbHelp {
  Say '  - кабель с передачей данных (кабель «только зарядка» не подойдёт), другой USB-разъём;'
  Say '  - закрыты программы, которые держат порт: Arduino IDE, монитор порта, другая установка;'
  Say '  - драйвер USB-порта платы. Название - на микросхеме рядом с USB-разъёмом платы:'
  Say '      CP2102 / CP210x:  https://www.silabs.com/developers/usb-to-uart-bridge-vcp-drivers'
  Say '      CH340 / CH341:    https://www.wch-ic.com/downloads/CH341SER_EXE.html'
  Say '      CH9102 / CH343:   https://www.wch-ic.com/downloads/CH343SER_EXE.html'
}
function FlashHelp {
  Say 'Что проверить:' 'Yellow'
  UsbHelp
  Say '  - если долго висит «Connecting...»: запусти ещё раз и, когда появится «Connecting...»,'
  Say '    зажми кнопку BOOT на плате и держи, пока не пойдут проценты.'
  Say 'Прерванная запись плату не портит: загрузчик ESP32 зашит в сам чип, просто запусти установку ещё раз.'
}
# COM-порты с названиями; USB-мосты плат ESP32 узнаём по названию
function Ports {
  @(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '\(COM\d+\)' } | ForEach-Object {
    [pscustomobject]@{ Port = [regex]::Match($_.Name, 'COM\d+').Value; Name = $_.Name; Usb = ($_.Name -match 'CP210|CH34|CH910|USB-SERIAL|USB Serial|UART|FTDI|USB-to') }
  } | Sort-Object Port)
}
function PickPort {
  while ($true) {
    $all = Ports; $usb = @($all | Where-Object { $_.Usb })
    if ($usb.Count -eq 1) { Say "Найдена плата: $($usb[0].Name)" 'Green'; return $usb[0].Port }
    if ($usb.Count -gt 1) {
      Say 'Найдено несколько USB-портов:'
      for ($i = 0; $i -lt $usb.Count; $i++) { Say ("  {0}. {1}" -f ($i + 1), $usb[$i].Name) }
      $a = Ask 'Впиши номер строки с нужной платой и нажми Enter'
      if ($a -match '^\d+$' -and [int]$a -ge 1 -and [int]$a -le $usb.Count) { return $usb[[int]$a - 1].Port }
      if ($Auto) { Fail 'Несколько плат - выбери порт.' }
      continue
    }
    Say 'Плата не найдена. Что проверить:' 'Yellow'
    UsbHelp
    if ($all.Count) { Say 'Другие COM-порты на компьютере (если плата среди них - впиши номер строки):'; for ($i = 0; $i -lt $all.Count; $i++) { Say ("  {0}. {1}" -f ($i + 1), $all[$i].Name) } }
    $a = Ask 'Подключи плату и нажми Enter, чтобы поискать ещё раз'
    if ($a -match '^\d+$' -and [int]$a -ge 1 -and [int]$a -le $all.Count) { return $all[[int]$a - 1].Port }
    if ($Auto) { Fail 'Плата не найдена.' }
  }
}
# esptool пишет прямо в окно (видно проценты); вызов через & внутри функции забрал бы весь его вывод в результат функции
function Esptool([string[]]$a) {
  $p = Start-Process -FilePath $esptool -ArgumentList $a -WorkingDirectory $files -NoNewWindow -PassThru
  $null = $p.Handle; $p.WaitForExit(); return [int]$p.ExitCode
}
# Какой чип на плате: прошивка - только для обычного ESP32 (WROOM-32), не для C3/S3/S2/C6 и не для ESP8266
function ChipCheck([string]$port) {
  Push-Location $files; try { $out = (& $esptool --port $port --baud 115200 read_mac 2>&1 | Out-String); $rc = $LASTEXITCODE } finally { Pop-Location }
  $chip = [regex]::Match($out, 'Chip is ([^\r\n]+)').Groups[1].Value.Trim()
  if ($rc -ne 0 -or -not $chip) { Say 'Не удалось связаться с платой или определить её чип.' 'Red'; Say 'Это бывает, если плата не обычный ESP32 (например ESP32-C3 или S3) - для них эта прошивка не подходит.' 'Yellow'; FlashHelp; Done 1 }
  if ($chip -notmatch '^ESP32(?![-‐]?[CSH]\d)' -or $chip -match 'ESP8266') { Say "Чип платы: $chip. Эта прошивка - только для обычного ESP32 (модули WROOM-32, 32D, 32E, 32U). Установка остановлена." 'Red'; Done 1 }
  Say "Чип: $chip - подходит." 'Green'
  $m = [regex]::Match($out, 'MAC: ([0-9a-fA-F:]{17})').Groups[1].Value; if ($m) { $script:mac = ($m -replace ':', '').ToLower() }
}
# Настройки Xendil лежат в его файловой системе SPIFFS внутри памяти платы: достаём их из копии, без Wi-Fi и без сети.
# Таблица разделов (с адреса 0x8000): первый раздел данных SPIFFS (тип 1, подтип 0x82) - адрес и размер
function PartSpiffs([byte[]]$pt, [int]$at) {
  for ($i = $at; $i + 32 -le $pt.Length -and $i -lt $at + 0xC00; $i += 32) {
    if ($pt[$i] -ne 0xAA -or $pt[$i + 1] -ne 0x50) { break }
    if ($pt[$i + 2] -eq 1 -and $pt[$i + 3] -eq 0x82) { return @([BitConverter]::ToUInt32($pt, $i + 4), [BitConverter]::ToUInt32($pt, $i + 8)) }
  }
  return $null
}
# SPIFFS как в ESP32 Arduino: страница 256 байт, блок 4096, первая страница блока - служебная таблица.
# Страница индекса файла: имя и размер; страницы данных: по 251 байту, номер куска - в заголовке страницы.
function XendilFiles([byte[]]$d, [int]$off, [int]$size, [string]$dir) {
  $PG = 256; $DS = 251; $idx = @{}; $data = @{}
  $np = [math]::Floor([math]::Min($size, $d.Length - $off) / $PG)
  for ($p = 0; $p -lt $np; $p++) {
    if ($p % 16 -eq 0) { continue }
    $o = $off + $p * $PG; $oid = [int][BitConverter]::ToUInt16($d, $o); $span = [int][BitConverter]::ToUInt16($d, $o + 2); $fl = [int]$d[$o + 4]
    if ($oid -eq 0xFFFF -or $oid -eq 0 -or ($fl -band 3) -ne 0 -or ($fl -band 0x80) -eq 0) { continue }   # свободная, недописанная или удалённая
    if (($fl -band 4) -eq 0) {
      if (($oid -band 0x8000) -and $span -eq 0 -and ($fl -band 0x40)) {
        $nb = [Array]::IndexOf($d, [byte]0, $o + 13, 32); if ($nb -lt 0) { $nb = $o + 45 }
        $idx[$oid -band 0x7FFF] = @([Text.Encoding]::UTF8.GetString($d, $o + 13, $nb - $o - 13), [int64][BitConverter]::ToUInt32($d, $o + 8))
      }
    } elseif (-not ($oid -band 0x8000)) { $data["$oid/$span"] = $o + 5 }
  }
  $got = @()
  foreach ($k in $idx.Keys) {   # только то, что переносит приветствие; SetMain.txt (там пароль от Wi-Fi) не трогаем
    $name = $idx[$k][0].TrimStart('/'); $len = $idx[$k][1]
    if (@('SetLight.txt', 'SetCool.txt', 'SetTimer.txt', 'GalleryCTime.txt') -notcontains $name -or $len -le 0 -or $len -gt 1MB) { continue }   # 0.6.78: + SetTimer.txt (реле и таймеры переносятся с 0.6.50)
    $buf = New-Object byte[] $len; $ok = $true
    for ($s = 0; $s * $DS -lt $len; $s++) { $src = $data["$k/$s"]; if ($null -eq $src) { $ok = $false; break }; [Array]::Copy($d, $src, $buf, $s * $DS, [math]::Min($DS, $len - $s * $DS)) }
    if ($ok) { New-Item -ItemType Directory -Force $dir | Out-Null; [IO.File]::WriteAllBytes((Join-Path $dir $name), $buf); $got += $name }
  }
  return $got
}
function SaveXendil([byte[]]$d, [int]$off, [int]$size) {
  $got = @(); try { $got = @(XendilFiles $d $off $size $xdir) } catch {}
  $script:xgot = $got   # 0.6.88: в память платы - только файлы этого раза
  if (($got -contains 'SetLight.txt') -and ($got -contains 'SetCool.txt') -and ($got -contains 'GalleryCTime.txt')) { Say ('Настройки Xendil сохранены: ' + ($got -join ', ') + " - в папке $xdir") 'Green'; return $true }
  if ($got.Count) { Say ('Сохранена только часть настроек Xendil: ' + ($got -join ', ') + '. Остальное зададите вручную.') 'Yellow'; return $true }
  Say 'Настроек Xendil на плате не нашлось (на ней была не Xendil или она новая). Каналы зададите в приветствии вручную.'
  return $false
}
# mklittlefs: вывод - в файлы (в окне он не нужен), код возврата - как у esptool
function Mk([string[]]$a) {
  $p = Start-Process -FilePath (Join-Path $files 'mklittlefs.exe') -ArgumentList $a -WorkingDirectory $files -NoNewWindow -PassThru -RedirectStandardOutput (Join-Path $files '_mk.out') -RedirectStandardError (Join-Path $files '_mk.err')
  $null = $p.Handle; if (-not $p.WaitForExit(120000)) { try { $p.Kill() } catch {}; return 1 }; return [int]$p.ExitCode
}
# 0.6.88: настройки Xendil - в память платы вместе с прошивкой: приветствие найдёт их само (прошивали с одного компьютера, а настраивают
# с телефона или другого - файлы искать не нужно). Файлы прошивки (LittleFS) берём из образа выпуска, добавляем xen_SetLight.txt и др.
# и собираем заново той же утилитой mklittlefs, которой PlatformIO собрал выпуск (страница 256 байт, блок 4096, раздел 0x160000 с 0x290000).
# Собранный образ распаковываем обратно и сверяем каждый файл по SHA-256. Любая ошибка - $null: ставим образ выпуска как раньше,
# настройки остаются в папке для переноса вручную. Прошивка, разметка памяти и стирание не меняются - отличаются только файлы.
function XenImage {
  if (-not (Test-Path (Join-Path $files 'mklittlefs.exe'))) { return $null }
  $FS = 0x290000; $FN = 0x160000; $tmp = @('_xfs_u', '_xfs_c', '_xfs_rel.bin', '_xfs_new.bin', '_mk.out', '_mk.err')
  $u = Join-Path $files '_xfs_u'; $c = Join-Path $files '_xfs_c'; $out = Join-Path $files '_full_xen.bin'
  try {
    foreach ($t in $tmp + '_full_xen.bin') { Remove-Item (Join-Path $files $t) -Recurse -Force -ErrorAction SilentlyContinue }
    $full = [IO.File]::ReadAllBytes((Join-Path $files $bin)); if ($full.Length -lt $FS + $FN) { return $null }
    $rel = New-Object byte[] $FN; [Array]::Copy($full, $FS, $rel, 0, $FN); [IO.File]::WriteAllBytes((Join-Path $files '_xfs_rel.bin'), $rel)
    if ((Mk @('-u', '_xfs_u', '-b', '4096', '-p', '256', '-s', "$FN", '_xfs_rel.bin')) -ne 0 -or -not (Test-Path (Join-Path $u 'index.htm.gz'))) { return $null }
    $base = @(Get-ChildItem $u -File).Count; $n = 0; $sz = 0
    foreach ($f in @('SetLight.txt', 'SetCool.txt', 'SetTimer.txt', 'GalleryCTime.txt')) { if ($script:xgot -contains $f) { Copy-Item (Join-Path $xdir $f) (Join-Path $u "xen_$f") -Force; $n++; $sz += (Get-Item (Join-Path $u "xen_$f")).Length } }
    $sl = Join-Path $u 'xen_SetLight.txt'
    if (-not (Test-Path $sl) -or [IO.File]::ReadAllText($sl) -notmatch 'LPWMChanelLED') { return $null }   # без настоящего SetLight.txt каналы и график не перенести
    if ($sz -gt 200KB) { return $null }   # память платы нужна и под обновление страницы (≈420 КБ на время замены)
    if ((Mk @('-c', '_xfs_u', '-b', '4096', '-p', '256', '-s', "$FN", '_xfs_new.bin')) -ne 0) { return $null }
    $new = [IO.File]::ReadAllBytes((Join-Path $files '_xfs_new.bin')); if ($new.Length -ne $FN) { return $null }
    if ((Mk @('-u', '_xfs_c', '-b', '4096', '-p', '256', '-s', "$FN", '_xfs_new.bin')) -ne 0) { return $null }
    $a = @(Get-ChildItem $u -File | Sort-Object Name); $b = @(Get-ChildItem $c -File | Sort-Object Name)
    if ($a.Count -ne $base + $n -or $b.Count -ne $a.Count) { return $null }
    for ($i = 0; $i -lt $a.Count; $i++) {
      if ($a[$i].Name -ne $b[$i].Name -or (Get-FileHash $a[$i].FullName -Algorithm SHA256).Hash -ne (Get-FileHash $b[$i].FullName -Algorithm SHA256).Hash) { return $null }
    }
    [Array]::Copy($new, 0, $full, $FS, $FN); [IO.File]::WriteAllBytes($out, $full)
    return '_full_xen.bin'
  } catch { return $null }
  finally { foreach ($t in $tmp) { Remove-Item (Join-Path $files $t) -Recurse -Force -ErrorAction SilentlyContinue } }
}

Say "Alterston Light $V - установка и обновление на плате ESP32" 'White'
Say ''
Say 'Перед началом:' 'Yellow'
Say '  1. Питание светодиодов 24-29 В ВЫКЛЮЧЕНО.' 'Yellow'
Say '     Надёжнее всего вынуть плату ESP32 из контроллера.' 'Yellow'
Say '     Иначе, пока идёт работа с памятью, все цвета светильника загорятся на полную.' 'Yellow'
Say '  2. Плата подключена к компьютеру USB-кабелем.'
Say '  3. Установщик сам поймёт, что на плате: Xendil (сохранит копию и настройки) или уже Alterston Light (обновит, настройки останутся).'
Ask 'Всё так? Нажми Enter' | Out-Null
if (-not (Test-Path $esptool) -or -not (Test-Path (Join-Path $files $bin))) { Fail 'Не хватает файлов в папке files. Распакуй архив целиком (не запускай установку прямо из архива) и запусти ещё раз.' }

# ---------- 1. плата ----------
Step 1 'Ищу плату'
if (-not $Port) { $Port = PickPort }
Say "Порт: $Port"
ChipCheck $Port

# ---------- 2. что на плате и что с ним сделать ----------
Step 2 'Что сейчас на плате'
New-Item -ItemType Directory -Force $store | Out-Null
$xdir = Join-Path $store "настройки_xendil_$mac"; $xok = $false; $updated = $false
Say 'Читаю с платы таблицу разделов памяти.'
$tp = Join-Path $files '_pt.bin'; Remove-Item $tp -ErrorAction SilentlyContinue
$rc = Esptool @('--chip', 'esp32', '--port', $Port, '--baud', '115200', 'read_flash', '0x8000', '0x1000', '_pt.bin')
if ($rc -ne 0 -or -not (Test-Path $tp)) { Say 'Не получилось прочитать плату.' 'Red'; FlashHelp; Done 1 }
$ptb = [IO.File]::ReadAllBytes($tp); Remove-Item $tp -ErrorAction SilentlyContinue
$sp = PartSpiffs $ptb 0
# своя разметка: файлы (LittleFS) с 0x290000 размером 0x160000; у Xendil файлы с 0x291000
$xmine = $true   # 0.6.88: настройки в память платы - только с этой же платы (копия по MAC)
$kind = if ($ptb[0] -eq 0xFF -and $ptb[1] -eq 0xFF) { 'empty' } elseif ($sp -and $sp[0] -eq 0x290000 -and $sp[1] -eq 0x160000) { 'al' } elseif ($sp -and $sp[0] -eq 0x291000) { 'xendil' } else { 'other' }
$old = @(Get-ChildItem -Path $top, $store -Filter 'backup_*.bin' -ErrorAction SilentlyContinue | Where-Object { $_.Length -eq 4194304 } | Sort-Object LastWriteTime -Descending)
if ($mac -ne 'board') { $mine = @($old | Where-Object { $_.Name -like "*_$mac.bin" }); if ($mine.Count) { $old = $mine } }   # копия именно этой платы - по MAC в имени
Say ''
if ($kind -eq 'al') {
  Say 'На плате, похоже, уже Alterston Light (или другая прошивка с такой же разметкой памяти).' 'Green'
  Say 'Что сделать:'
  Say '  1 - обновить до новой версии, все настройки сохранятся: каналы, график, «Аквариум», галерея, Wi-Fi,'
  Say '      пароли, журнал. Около 2 минут (советую).'
  Say '  2 - сделать полную копию платы (около 6 минут) и установить с нуля: настройки сотрутся,'
  Say '      а по копии 2_VERNUT_KAK_BYLO.bat вернёт всё как было.'
  Say '  3 - установить с нуля без копии: настройки сотрутся.'
  $menu = '123'
} elseif ($kind -eq 'xendil') {
  Say 'На плате Xendil.' 'Green'
  Say 'Что сохранить перед прошивкой:'
  Say '  1 - полную копию, около 6 минут (советую). По ней 2_VERNUT_KAK_BYLO.bat вернёт плату как было,'
  Say '      а настройки Xendil (каналы, график, вентиляторы, галерея графиков) лягут в память платы вместе с новой прошивкой:'
  Say '      приветствие найдёт их само, файлы выбирать не нужно.'
  Say '  2 - только настройки Xendil, около 2-3 минут: так же лягут в память платы, но вернуть Xendil будет нельзя.'
  Say '  3 - ничего: настройки Xendil не нужны.'
  if ($old.Count) { Say "  4 - взять копию, которая уже есть в папке: $($old[0].Name) от $($old[0].LastWriteTime.ToString('dd.MM.yyyy HH:mm')) (если она с этой же платы)." }
  $menu = if ($old.Count) { '1234' } else { '123' }
} elseif ($kind -eq 'empty') {
  Say 'Плата пустая: копировать с неё нечего.' 'Green'; $menu = ''
} else {
  Say 'На плате какая-то другая прошивка.'
  Say '  1 - полную копию, около 6 минут (советую): по ней 2_VERNUT_KAK_BYLO.bat вернёт эту прошивку.'
  Say '  3 - ничего не копировать.'
  $menu = '13'
}
$a = '3'
while ($menu) {
  $a = if ($Copy) { $Copy } else { (Ask 'Впиши цифру и нажми Enter (просто Enter - 1)').Trim() }
  if (-not $a) { $a = '1' }
  if ($a.Length -eq 1 -and $menu.Contains($a)) {
    $lose = $a -eq '3' -or ($kind -eq 'al' -and $a -eq '2')
    if ($lose -and -not $Auto -and (Ask 'Настройки и то, что сейчас на плате, сотрутся. Точно? Впиши «да»') -notmatch '^\s*да\s*$') { continue }
    break
  }
  if ($Auto) { Fail 'Неверный выбор.' }
  Say ('Впиши одну из цифр: ' + (($menu.ToCharArray()) -join ', ') + '.') 'Yellow'
}
$full = ($a -eq '1' -and $kind -ne 'al') -or ($a -eq '2' -and $kind -eq 'al')
if ($full) {
  $bk = "backup_$(Get-Date -Format 'yyyyMMdd_HHmm')_$mac.bin"; $tmp = Join-Path $files '_backup.bin'; Remove-Item $tmp -ErrorAction SilentlyContinue
  Say "Копирую память платы (около 6 минут). Не отключай плату."
  $rc = Esptool @('--chip', 'esp32', '--port', $Port, '--baud', '115200', 'read_flash', '0', '0x400000', '_backup.bin')
  if ($rc -ne 0 -or -not (Test-Path $tmp) -or (Get-Item $tmp).Length -ne 4194304) { Remove-Item $tmp -ErrorAction SilentlyContinue; Say 'Копия не получилась.' 'Red'; FlashHelp; Done 1 }
  $bkp = Join-Path $store $bk; Move-Item $tmp $bkp -Force
  Say "Копия сохранена: $bkp" 'Green'
  Say 'Она лежит в «Документах», а не в папке установщика: удалишь папку старой версии - копия останется. Скопируй её ещё на флешку или в облако: по ней 2_VERNUT_KAK_BYLO.bat вернёт плату как было.' 'Green'
  if ($kind -eq 'xendil') { $d = [IO.File]::ReadAllBytes($bkp); $xok = SaveXendil $d $sp[0] $sp[1] }
}
elseif ($kind -eq 'xendil' -and $a -eq '4') {
  Say "Беру копию $($old[0].Name), новую не делаю."
  $xmine = $mac -ne 'board' -and $old[0].Name -like "*_$mac.bin"
  $d = [IO.File]::ReadAllBytes($old[0].FullName); $pt = PartSpiffs $d 0x8000
  if ($pt) { $xok = SaveXendil $d $pt[0] $pt[1] } else { $null = SaveXendil @() 0 0 }
}
elseif ($kind -eq 'xendil' -and $a -eq '2') {
  $tf = Join-Path $files '_xfs.bin'
  try {
    Say ('Читаю настройки Xendil (около {0} минут). Не отключай плату.' -f [math]::Ceiling($sp[1] / 11000 / 60))
    $rc = Esptool @('--chip', 'esp32', '--port', $Port, '--baud', '115200', 'read_flash', ('0x{0:X}' -f $sp[0]), ('0x{0:X}' -f $sp[1]), '_xfs.bin')
    if ($rc -ne 0 -or -not (Test-Path $tf)) { Say 'Настройки прочитать не получилось.' 'Red'; FlashHelp; Done 1 }
    $xok = SaveXendil ([IO.File]::ReadAllBytes($tf)) 0 $sp[1]
  } finally { Remove-Item $tf -ErrorAction SilentlyContinue }
}
elseif ($kind -eq 'al' -and $a -eq '1') {
  # Обновление с сохранением всего: новая прошивка - на место прошивки, новая страница - во второй раздел прошивки (app1),
  # оттуда прошивка при первом запуске сама переносит её в свои файлы. Файлы с настройками и память Wi-Fi не трогаем.
  $ota = "alterston_light_${V}_ota.bin"; $pu = "alterston_light_${V}_page_usb.bin"
  if (-not (Test-Path (Join-Path $files $ota)) -or -not (Test-Path (Join-Path $files $pu)) -or -not (Test-Path (Join-Path $files 'boot_app0.bin'))) { Fail 'Не хватает файлов в папке files. Распакуй архив целиком и запусти ещё раз.' }
  Step 3 "Обновление до Alterston Light $V (около 2 минут)"
  Say 'Запишу новую прошивку и страницу. Файлы с настройками на плате не трогаю.'
  Say 'На всякий случай копию настроек можно скачать заранее: на странице «Информация» → «Скачать копию».'
  Ask 'Нажми Enter, чтобы начать' | Out-Null
  $rc = Esptool @('--chip', 'esp32', '--port', $Port, '--baud', '115200', 'write_flash', '-z', '0xe000', 'boot_app0.bin', '0x10000', $ota, '0x150000', $pu)
  if ($rc -ne 0) { Say 'Запись не получилась. Настройки на плате не тронуты - запусти обновление ещё раз.' 'Red'; FlashHelp; Done 1 }
  $updated = $true
}
else { Say 'Копию не делаю.' }
if ($kind -eq 'empty' -and $mac -ne 'board' -and (Test-Path (Join-Path $xdir 'SetLight.txt'))) {   # 0.6.88: прошлая установка оборвалась после стирания
  $script:xgot = @(@('SetLight.txt', 'SetCool.txt', 'SetTimer.txt', 'GalleryCTime.txt') | Where-Object { Test-Path (Join-Path $xdir $_) }); $xok = $true
  Say "Нашлись настройки Xendil этой платы с прошлой установки (папка $xdir): положу их в плату." 'Green'
}

if ($updated) {
  Say ''
  Say "Готово: Alterston Light обновлена до $V, все настройки на месте." 'Green'
  Say 'Дальше:' 'White'
  Say '  1. Поставь плату обратно в светильник и включи питание. При первом включении плата переносит новую страницу к себе - это пара секунд.'
  Say '  2. Открой страницу светильника по прежнему адресу и обнови её в браузере (Ctrl+F5 на компьютере).'
  Say "  3. На вкладке «Информация» проверь строки «Прошивка» и «Страница»: должно быть $V."
  Done 0
}

# ---------- 3. прошивка с нуля ----------
$img = $bin; $xenOnBoard = $false
if ($xok -and -not $xmine) { Say 'Копия взята не с этой платы - её настройки в память платы не кладу: перенесёшь их из папки, если нужно (подскажу в конце).' 'Yellow' }
elseif ($xok -and ($script:xgot -contains 'SetLight.txt')) {
  Say 'Готовлю настройки Xendil для памяти платы.'
  $xi = XenImage
  if ($xi) { $img = $xi; $xenOnBoard = $true; Say 'Настройки Xendil лягут в память платы вместе с прошивкой: приветствие найдёт их само.' 'Green' }
  else { Say 'Положить настройки Xendil в память платы не получилось - ставлю как обычно, а настройки перенесёшь из папки (подскажу в конце).' 'Yellow' }
}
Step 3 "Прошивка Alterston Light $V (около 2-3 минут)"
Say 'Сначала память платы будет полностью стёрта, потом записана новая прошивка.'
Ask 'Нажми Enter, чтобы начать' | Out-Null
# полное стирание: от старой прошивки не остаётся ничего, в том числе в конце памяти, куда образ не пишет
Say 'Стираю память платы (около 15 секунд).'
$rc = Esptool @('--chip', 'esp32', '--port', $Port, '--baud', '115200', 'erase_flash')
if ($rc -ne 0) { Say 'Память стереть не получилось.' 'Red'; FlashHelp; Done 1 }
Say 'Записываю прошивку.'
$rc = Esptool @('--chip', 'esp32', '--port', $Port, '--baud', '115200', 'write_flash', '-z', '0x0', $img)
if ($xenOnBoard) { Remove-Item (Join-Path $files $img) -ErrorAction SilentlyContinue }
if ($rc -ne 0) { Say 'Прошивка не записалась. Плата сейчас пустая - просто запусти установку ещё раз (копию заново делать не нужно).' 'Red'; FlashHelp; Done 1 }

Say ''
Say "Готово: Alterston Light $V установлена." 'Green'
Say 'Дальше:' 'White'
Say '  1. Поставь плату обратно в светильник и включи питание (страница откроется и от одного USB).'
Say '  2. На телефоне или компьютере подключись к Wi-Fi «Alterston_Light», пароль adminadmin.'
Say '  3. Открой в браузере http://192.168.4.1 - откроется приветствие с первой настройкой.'
if ($xenOnBoard) { Say '  4. В приветствии будет «Настройки Xendil уже в светильнике» → «Перенести»: файлы выбирать не нужно.'; Say "     Запасная копия этих настроек - в папке $xdir." }
elseif ($xok) { Say "  4. В приветствии: «Да, перенести настройки» → «Выбрать файлы…» → все файлы из папки $xdir (сейчас откроется)."; if (-not $Auto) { Invoke-Item $xdir } }
Say "Копии плат и сохранённые настройки - в папке $store." 
Say 'Подробно - в файле USTANOVKA.pdf. Вернуть как было - 2_VERNUT_KAK_BYLO.bat.'
Done 0
