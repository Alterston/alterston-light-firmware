﻿# Alterston Light: обновление по Wi-Fi с сайта автора БЕЗ страницы светильника (0.6.97).
# Запускается из 4_OBNOVIT_PO_WIFI.bat. Нужен, если страница светильника не открывается в браузере - например, после 0.6.94
# (13.11.2026 она около 40 минут лежала на сайте и отдавала страницу так, что браузер её не открывал; свет и кнопки работали).
# Делает то же, что кнопка «Обновить» на странице: светильник сам скачивает новую версию с сайта, сверяет SHA-256 и перезагружается.
# Настройки, график и пароли не меняются. Пароль светильника (если задан) уходит только в светильник, в домашней сети.
# Без вопросов (для проверки): -Ip 192.168.1.124 [-Pass пароль] -Yes
param([string]$Ip, [string]$Pass, [switch]$Yes)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
function Say([string]$t, [string]$c = 'Gray') { Write-Host $t -ForegroundColor $c }
function Done([int]$code) { if (-not $Yes) { Read-Host 'Нажми Enter, чтобы закрыть окно' | Out-Null }; exit $code }
try { $Host.UI.RawUI.WindowTitle = 'Alterston Light - обновление по Wi-Fi' } catch {}
Say 'Alterston Light - если страница светильника не открывается' 'Cyan'
Say ''
Say '  Этот файл нужен, только если страница светильника в браузере не открывается.'
Say '  Он попросит светильник самому скачать с сайта автора последнюю версию и поставить её - как кнопка «Обновить» на странице.'
Say '  Настройки, график и пароли не меняются. Ничего не произойдёт, пока ты не впишешь адрес и не напишешь «да».'
Say '  Для первой установки он не нужен - для неё 1_USTANOVIT.bat.'
Say ''
Say '  Компьютер должен быть в той же сети Wi-Fi, что и светильник.'
Say '  Адрес светильника: в роутере (список устройств), в приложении Alterston Light или на экранчике светильника.'
Say ''
$ip = $(if ($Ip) { $Ip } else { (Read-Host 'Адрес светильника, например 192.168.1.102') }).Trim()
if ($ip -notmatch '^\d{1,3}(\.\d{1,3}){3}$' -and $ip -notmatch '^[a-zA-Z0-9-]+(\.local)?$') { Say 'Это не похоже на адрес светильника.' 'Red'; Done 1 }
$pw = $(if ($Ip) { $Pass } else { Read-Host 'Пароль светильника (если не задавал - просто Enter)' })
$h = @{}; if ($pw) { $h['X-Pass'] = $pw }
$base = "http://$ip"
# ответ светильника - UTF-8 без charset в заголовке: Invoke-RestMethod в PowerShell 5.1 прочёл бы его как Latin-1 (кракозябры)
function Get-J([string]$p) { $r = Invoke-WebRequest -Uri ($base + $p) -TimeoutSec 10 -Headers $h -UseBasicParsing; [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray()) | ConvertFrom-Json }
function Post-J([string]$p, $o) { Invoke-RestMethod -Uri ($base + $p) -Method Post -TimeoutSec 15 -Headers $h -Body ($o | ConvertTo-Json -Compress) -ContentType 'application/json' }
try { $info = Get-J '/api/info' } catch { Say "Светильник по адресу $ip не ответил: $($_.Exception.Message)" 'Red'; Done 1 }
Say ("Светильник ответил: прошивка {0}" -f $info.fw) 'Green'
# 0.6.99: страница открывается нормально - этот файл не нужен (не вводим в заблуждение: обновлять лучше со страницы)
$pageOk = $false
try { $r = Invoke-WebRequest -Uri ($base + '/') -TimeoutSec 20 -Headers @{'Accept-Encoding' = 'gzip'} -UseBasicParsing
  $enc = [string]$r.Headers['Content-Encoding']; $pageOk = ($r.StatusCode -eq 200) -and ($enc -notmatch ',') } catch {}
if ($pageOk) {
  Say ("Страница светильника открывается нормально: http://{0}/" -f $ip) 'Green'
  Say '  Этот файл тебе не нужен. Обновлять удобнее на странице: «Общие» → «Обновления» → «Проверить обновление прошивки».'
  $go = $(if ($Yes) { 'да' } else { Read-Host 'Всё равно проверить обновление отсюда? Напиши да и нажми Enter (просто Enter - выход)' })
  if ($go.Trim().ToLower() -ne 'да') { Say 'Ничего не менял.'; Done 0 }
} else { Say '  Страница светильника сейчас не открывается как надо - обновление с сайта её починит, если на сайте версия новее.' 'Yellow' }
try { Post-J '/api/update' @{check = $true} | Out-Null } catch { Say "Проверка не запустилась: $($_.Exception.Message) (пароль верный?)" 'Red'; Done 1 }
Say 'Светильник проверяет сайт обновлений…'
$u = $null; for ($i = 0; $i -lt 40; $i++) { Start-Sleep 1.5; try { $u = Get-J '/api/update'; if (-not $u.busy) { break } } catch {} }
if (-not $u -or $u.err) { Say ("Проверка не удалась: {0}" -f $(if ($u) { $u.err } else { 'нет ответа' })) 'Red'; Done 1 }
Say ("Сейчас стоит {0}, на сайте {1}" -f $u.cur, $u.latest)
if (-not $u.newer) { Say 'На сайте не новее - обновлять нечего.' 'Yellow'; Done 0 }
$ok = $(if ($Yes) { 'да' } else { Read-Host ("Установить {0}? Свет на секунду погаснет. Напиши да и нажми Enter" -f $u.latest) })
if ($ok.Trim().ToLower() -ne 'да') { Say 'Отменено.'; Done 0 }
try { Post-J '/api/update' @{install = $true} | Out-Null } catch { Say "Установка не запустилась: $($_.Exception.Message)" 'Red'; Done 1 }
Say 'Светильник скачивает и ставит обновление. Не выключай питание…' 'Yellow'
$last = ''; for ($i = 0; $i -lt 150; $i++) { Start-Sleep 2
  try { $u = Get-J '/api/update'; $t = ("{0} {1} %" -f $u.phase, $u.pct); if ($t -ne $last) { Say "  $t"; $last = $t }; if (-not $u.busy -and $u.err) { Say ("Не получилось: {0}" -f $u.err) 'Red'; Done 1 } } catch { Say '  перезагружается…'; break } }
for ($i = 0; $i -lt 40; $i++) { Start-Sleep 3; try { $n = Get-J '/api/info'; if ($n.fw -ne $info.fw) { Say ("Готово: стоит {0}. Открой страницу светильника: http://{1}/" -f $n.fw, $ip) 'Green'; Done 0 } } catch {} }
Say 'Светильник пока не ответил новой версией. Подожди минуту и открой его страницу; если не откроется - 3_ZHURNAL_PO_USB.bat и автору.' 'Yellow'; Done 1
