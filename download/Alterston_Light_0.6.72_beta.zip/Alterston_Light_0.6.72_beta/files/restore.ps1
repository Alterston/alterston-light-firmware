﻿# Alterston Light: вернуть плату в прежнее состояние из копии памяти (backup_*.bin), которую сделала установка.
param([string]$Port, [string]$File, [switch]$Auto)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
# Окно консоли - на шрифт Consolas: старый «точечный» шрифт не показывает русские буквы в UTF-8 (вместо них «▼▼▼»)
try {
  Add-Type -Namespace AL -Name ConFont -MemberDefinition @'
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] public struct CFI { public uint cbSize; public uint nFont; public short X; public short Y; public int FontFamily; public int FontWeight; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string FaceName; }
[DllImport("kernel32.dll", SetLastError = true)] public static extern IntPtr GetStdHandle(int h);
[DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] public static extern bool SetCurrentConsoleFontEx(IntPtr h, bool max, ref CFI f);
'@ -ErrorAction Stop
  $cf = New-Object AL.ConFont+CFI; $cf.cbSize = [Runtime.InteropServices.Marshal]::SizeOf($cf); $cf.Y = 18; $cf.FontFamily = 54; $cf.FontWeight = 400; $cf.FaceName = 'Consolas'
  [void][AL.ConFont]::SetCurrentConsoleFontEx([AL.ConFont]::GetStdHandle(-11), $false, [ref]$cf)
  Start-Sleep -Milliseconds 200; Clear-Host   # после смены шрифта окно меняет размер; с чистого экрана текст не «съезжает», когда окно растягивают
} catch {}
$files = $PSScriptRoot; $top = Split-Path $files -Parent; $esptool = Join-Path $files 'esptool.exe'
try { $Host.UI.RawUI.WindowTitle = 'Alterston Light - вернуть как было' } catch {}
function Say([string]$t, [string]$c = 'Gray') { Write-Host $t -ForegroundColor $c }
function Ask([string]$t) { if ($Auto) { return '' } ; return Read-Host $t }
function Done([int]$code) { if (-not $Auto) { Read-Host 'Нажми Enter, чтобы закрыть окно' | Out-Null }; exit $code }
function Ports {
  @(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '\(COM\d+\)' } | ForEach-Object {
    [pscustomobject]@{ Port = [regex]::Match($_.Name, 'COM\d+').Value; Name = $_.Name; Usb = ($_.Name -match 'CP210|CH34|CH910|USB-SERIAL|USB Serial|UART|FTDI|USB-to') }
  } | Sort-Object Port)
}

Say 'Вернуть плату ESP32 в прежнее состояние из копии памяти' 'White'
Say 'Питание светодиодов 24-29 В ВЫКЛЮЧЕНО, плата подключена к компьютеру USB-кабелем.' 'Yellow'
$store = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Alterston Light'   # туда установщик кладёт копии плат (с 0.6.12)
$list = @(Get-ChildItem -Path $top, $store -Filter 'backup_*.bin' -ErrorAction SilentlyContinue | Where-Object { $_.Length -eq 4194304 } | Sort-Object LastWriteTime -Descending)
if ($File) { $pick = Get-Item $File } elseif (-not $list.Count) { Say "Копий backup_*.bin нет ни в этой папке, ни в $store. Положи файл копии сюда и запусти ещё раз." 'Red'; Done 1 }
else {
  Say "Копии плат (из этой папки и из $store, сверху самая свежая; в конце имени - MAC платы):"
  for ($i = 0; $i -lt $list.Count; $i++) { Say ("  {0}. {1}   ({2})" -f ($i + 1), $list[$i].Name, $list[$i].LastWriteTime.ToString('dd.MM.yyyy HH:mm')) }
  Say 'Чтобы вернуть Xendil, нужна копия, снятая ещё с Xendil (обычно самая первая по дате).' 'Yellow'
  $a = Ask 'Впиши номер копии (Enter - 1)'
  $n = 1; if ($a -match '^\d+$' -and [int]$a -ge 1 -and [int]$a -le $list.Count) { $n = [int]$a }
  $pick = $list[$n - 1]
}
if (-not $Port) {
  while ($true) {
    $usb = @(Ports | Where-Object { $_.Usb })
    if ($usb.Count -eq 1) { $Port = $usb[0].Port; Say "Плата: $($usb[0].Name)" 'Green'; break }
    if ($usb.Count -gt 1) { for ($i = 0; $i -lt $usb.Count; $i++) { Say ("  {0}. {1}" -f ($i + 1), $usb[$i].Name) }; $a = Ask 'Номер строки с платой'; if ($a -match '^\d+$' -and [int]$a -ge 1 -and [int]$a -le $usb.Count) { $Port = $usb[[int]$a - 1].Port; break } }
    else { Say 'Плата не найдена: проверь кабель (с передачей данных) и драйвер (см. USTANOVKA.pdf).' 'Yellow'; Ask 'Подключи плату и нажми Enter' | Out-Null }
    if ($Auto) { Say 'Плата не найдена.' 'Red'; Done 1 }
  }
}
Say "Запишу копию $($pick.Name) в плату на $Port. Всё, что сейчас на плате, сотрётся."
Ask 'Нажми Enter, чтобы начать, или закрой окно, чтобы отменить' | Out-Null
Copy-Item $pick.FullName (Join-Path $files '_restore.bin') -Force   # имя без русских букв и пробелов - старый esptool с ними не дружит
Push-Location $files
try { $p = Start-Process -FilePath $esptool -ArgumentList @('--chip', 'esp32', '--port', $Port, '--baud', '115200', 'write_flash', '0x0', '_restore.bin') -WorkingDirectory $files -NoNewWindow -PassThru; $null = $p.Handle; $p.WaitForExit(); $rc = [int]$p.ExitCode }   # проценты видно в окне
finally { Pop-Location; Remove-Item (Join-Path $files '_restore.bin') -ErrorAction SilentlyContinue }
if ($rc -ne 0) { Say 'Не получилось. Проверь кабель и порт; если долго висит «Connecting...», зажми кнопку BOOT на плате, пока не пойдут проценты, и запусти ещё раз.' 'Red'; Done 1 }
Say 'Готово, плата перезагрузится сама и будет работать как до установки.' 'Green'
Done 0
