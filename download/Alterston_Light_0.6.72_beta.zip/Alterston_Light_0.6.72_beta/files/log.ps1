﻿# Alterston Light: журнал платы по USB, когда по Wi-Fi к ней не подключиться.
# Запускается из 3_ZHURNAL_PO_USB.bat. Ничего на плату не пишет: перезапускает её и записывает всё, что она выводит в порт,
# в файл на рабочем столе - журнал событий (прошивка 0.6.35+ выводит его при каждом запуске) и отчёт ESP32 о зависании.
param([string]$Port, [int]$Sec = 180)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
function Say([string]$t, [string]$c = 'Gray') { Write-Host $t -ForegroundColor $c }
function Done([int]$code) { Read-Host 'Нажми Enter, чтобы закрыть окно' | Out-Null; exit $code }
try { $Host.UI.RawUI.WindowTitle = 'Alterston Light - журнал платы по USB' } catch {}
function Ports {
  @(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '\(COM\d+\)' } | ForEach-Object {
    [pscustomobject]@{ Port = [regex]::Match($_.Name, 'COM\d+').Value; Name = $_.Name; Usb = ($_.Name -match 'CP210|CH34|CH910|USB-SERIAL|USB Serial|UART|FTDI|USB-to') }
  } | Sort-Object Port)
}

Say 'Alterston Light - журнал платы по USB' 'Cyan'
Say ''
Say '  1. Питание светодиодов 24-29 В ВЫКЛЮЧИ, плату подключи к компьютеру USB-кабелем.' 'Yellow'
Say '  2. Плата перезапустится и сама выведет журнал событий. Запись идёт 3 минуты.'
Say '  3. Пока идёт запись, сделай то, после чего плата зависала: подключись телефоном'
Say '     к её Wi-Fi, открой страницу, нажми кнопку. Закончить раньше - клавиша Q.'
Say '  4. Файл с журналом появится на рабочем столе - пришли его автору.'
Say ''

if (-not $Port) {
  while ($true) {
    $all = Ports; $usb = @($all | Where-Object { $_.Usb })
    if ($usb.Count -eq 1) { $Port = $usb[0].Port; Say "Найдена плата: $($usb[0].Name)" 'Green'; break }
    $list = if ($usb.Count) { $usb } else { $all }
    if ($list.Count) {
      Say 'Выбери порт платы:'; for ($i = 0; $i -lt $list.Count; $i++) { Say ("  {0}. {1}" -f ($i + 1), $list[$i].Name) }
      $a = (Read-Host 'Впиши номер строки и нажми Enter').Trim()
      if ($a -match '^\d+$' -and [int]$a -ge 1 -and [int]$a -le $list.Count) { $Port = $list[[int]$a - 1].Port; break }
      continue
    }
    Say 'Плата не найдена: другой кабель (с передачей данных), другой USB-разъём или драйвер USB-порта (см. USTANOVKA.pdf).' 'Yellow'
    Read-Host 'Подключи плату и нажми Enter, чтобы поискать ещё раз' | Out-Null
  }
}

$desk = [Environment]::GetFolderPath('Desktop'); $out = Join-Path $desk ("Alterston_журнал_{0:yyyy-MM-dd_HH-mm}.txt" -f (Get-Date))
$sp = New-Object System.IO.Ports.SerialPort $Port, 115200, 'None', 8, 'One'
$sp.Encoding = [Text.Encoding]::UTF8; $sp.ReadTimeout = 200; $sp.DtrEnable = $false; $sp.RtsEnable = $false
try { $sp.Open() } catch { Say "Порт $Port занят или недоступен: закрой Arduino IDE, монитор порта, установщик - и запусти снова." 'Red'; Done 1 }
$w = New-Object System.IO.StreamWriter($out, $false, (New-Object Text.UTF8Encoding $true))
$w.WriteLine("Alterston Light - журнал платы по USB, порт $Port, начало $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
# перезапуск платы: EN в 0 и обратно (RTS), IO0 не трогаем (DTR) - плата стартует обычным образом и выводит журнал
try { $sp.DiscardInBuffer() } catch {}   # в буфере порта мог остаться хвост прошлого вывода
$sp.RtsEnable = $true; Start-Sleep -Milliseconds 150; $sp.RtsEnable = $false
Say "Запись в файл: $out" 'Green'
$t0 = Get-Date; $buf = ''
try {
  while (((Get-Date) - $t0).TotalSeconds -lt $Sec) {
    $q = $false; try { $q = [Console]::KeyAvailable -and ([Console]::ReadKey($true).Key -eq 'Q') } catch {}; if ($q) { break }
    $s = ''; try { $s = $sp.ReadExisting() } catch {}
    if ($s) {
      $buf += $s
      while (($i = $buf.IndexOf("`n")) -ge 0) {
        $line = $buf.Substring(0, $i).TrimEnd("`r"); $buf = $buf.Substring($i + 1)
        # загрузчик ESP32 в первые доли секунды пишет на другой скорости - в окне это «кракозябры»; заменяем одной пометкой
        $bad = ($line.ToCharArray() | Where-Object { [int]$_ -eq 0xFFFD -or ([int]$_ -lt 32 -and $_ -ne "`t") }).Count
        if ($line.Length -and $bad * 5 -gt $line.Length) { if (-not $boot) { $boot = $true; $line = '(загрузчик ESP32 - служебный вывод на другой скорости, пропущен)' } else { continue } }
        $st = '{0,6:N1} с  ' -f ((Get-Date) - $t0).TotalSeconds; $w.WriteLine($st + $line); $w.Flush()
        $c = if ($line -match 'watchdog|Guru|panic|abort|Backtrace|перезапуск') { 'Yellow' } else { 'Gray' }; Say ($st + $line) $c
      }
    } else { Start-Sleep -Milliseconds 50 }
  }
} finally { if ($buf) { $w.WriteLine($buf) }; $w.Close(); $sp.Close() }
Say ''
Say "Готово. Файл на рабочем столе: $(Split-Path $out -Leaf) - пришли его автору." 'Green'
Done 0
